#!/bin/bash

cd /work/data
./cnfpga.sh

cd /work/data/psFPGA
./configDriver.sh

cd /work/data
./cnfpga.sh

