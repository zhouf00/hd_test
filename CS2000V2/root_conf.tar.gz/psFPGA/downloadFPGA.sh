#!/bin/bash

while :
do 
    cp output_file.rbf fpgaUpgrad.bin
    echo download fpga Upgrad file:
    ./fpgaUpgradApp
    sleep 20
done

