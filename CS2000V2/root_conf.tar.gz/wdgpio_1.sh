#!/bin/sh
#RST_CLR    GPIO3_17
echo 113 > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio113/direction
echo 0 > /sys/class/gpio/gpio113/value
#KEY_TEST_CTRL    GPIO3_18
echo 114 > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio114/direction
echo 0 > /sys/class/gpio/gpio114/value
#KEY_TEST   GPIO3_19
echo 115 > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio115/direction
echo 0 > /sys/class/gpio/gpio115/value



