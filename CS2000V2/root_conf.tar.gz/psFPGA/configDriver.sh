#!/bin/bash

cd /work/data/psFPGA
rmmod PS_FPGAUpgrad.ko
rm /dev/PS_FPGA
usleep 500000
insmod PS_FPGAUpgrad.ko
mknod /dev/PS_FPGA c 250 0

./fpgaUpgradApp

