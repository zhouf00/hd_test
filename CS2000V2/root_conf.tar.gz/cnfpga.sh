#!/bin/bash

rmmod TEST.ko
rm /dev/fpga
usleep 500000
insmod TEST.ko
mknod /dev/fpga c 233 0


