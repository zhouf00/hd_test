#!/bin/bash
./configDriver.sh
./downloadFPGA.sh


