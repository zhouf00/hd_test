#!/bin/sh

mount -o remount,rw /


/home/root/init &

