#!/bin/sh

mount -o remount,rw /
ifconfig eth0 192.168.22.20 netmask 255.255.255.0
/home/root/mac && /home/root/doip
ifconfig eth0 up
ifconfig eth1 down

sysctl -w kernel.shmmax=2147483648 

/home/root/doip &
/home/root/init &

