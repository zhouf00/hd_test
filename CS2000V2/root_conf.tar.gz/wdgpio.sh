#!/bin/sh
#RST_CLR    GPIO3_17
echo 113 > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio113/direction
echo 0 > /sys/class/gpio/gpio113/value
#KEY_TEST_CTRL    GPIO3_18
echo 114 > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio114/direction
echo 0 > /sys/class/gpio/gpio114/value
#KEY_TEST   GPIO3_19
echo 115 > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio115/direction
echo 0 > /sys/class/gpio/gpio115/value

#mii1_crs.spi1_d0    GPIO3_1
echo 97 > /sys/class/gpio/export
echo "out" > /sys/class/gpio/gpio97/direction
echo 1 > /sys/class/gpio/gpio97/value

#mii1_rxerr.spi1_d1    GPIO3_2
echo 98 > /sys/class/gpio/export;
echo "out" > /sys/class/gpio/gpio98/direction;
echo 1 > /sys/class/gpio/gpio98/value


